# quick-open README

"quick-open". html 파일과 관련 있는 js 파일을 열수 있습니다.

## Features

에디터 화면에서 마우스 오른쪽 버튼을 누르고 "quick open" 메뉴를 크릭하면 화련한 html, js 를 열어 줍니다.

## Release Notes

1.0.0 first release
1.0.1 테스트용 알림 메시지 삭제

## publish

Publish for shinha new app project!

